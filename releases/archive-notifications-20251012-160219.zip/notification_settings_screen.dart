import 'package:flutter/material.dart';
import '../services/notification_service.dart';
import '../services/notification_settings.dart';

class NotificationSettingsScreen extends StatefulWidget {
  const NotificationSettingsScreen({super.key});

  @override
  State<NotificationSettingsScreen> createState() =>
      _NotificationSettingsScreenState();
}

class _NotificationSettingsScreenState
    extends State<NotificationSettingsScreen> {
  bool _notificationsEnabled = false;
  TimeOfDay? _selectedTime;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final enabled = await NotificationSettings.isHealthCheckEnabled();
    final time = await NotificationSettings.getHealthCheckTime();

    if (mounted) {
      setState(() {
        _notificationsEnabled = enabled;
        _selectedTime =
            time ?? const TimeOfDay(hour: 9, minute: 0); // Default to 9 AM
        _isLoading = false;
      });
    }
  }

  Future<void> _updateSchedule() async {
    if (_notificationsEnabled && _selectedTime != null) {
      await NotificationSettings.saveHealthCheckTime(_selectedTime!);
      await NotificationService.instance.scheduleHealthCheck(
        time: _selectedTime!,
      );
    } else {
      await NotificationSettings.setHealthCheckEnabled(false);
      await NotificationService.instance.cancelHealthCheckSchedule();
    }
  }

  Future<void> _selectTime() async {
    final time = await showTimePicker(
      context: context,
      initialTime: _selectedTime ?? const TimeOfDay(hour: 9, minute: 0),
    );

    if (time != null && mounted) {
      setState(() {
        _selectedTime = time;
      });
      await _updateSchedule();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Health Check Settings'),
        backgroundColor: Theme.of(context).primaryColor,
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SwitchListTile(
                    title: const Text('Daily Health Check Notifications'),
                    subtitle: const Text(
                      'Get reminded to check your plant\'s health status',
                    ),
                    value: _notificationsEnabled,
                    onChanged: (value) async {
                      setState(() {
                        _notificationsEnabled = value;
                      });
                      await _updateSchedule();
                    },
                  ),
                  const SizedBox(height: 16),
                  if (_notificationsEnabled) ...[
                    ListTile(
                      title: const Text('Notification Time'),
                      subtitle: Text(
                        _selectedTime != null
                            ? 'Daily at ${_selectedTime!.format(context)}'
                            : 'Not set',
                      ),
                      trailing: ElevatedButton(
                        onPressed: _selectTime,
                        child: const Text('Change Time'),
                      ),
                    ),
                    const Padding(
                      padding: EdgeInsets.all(16.0),
                      child: Text(
                        'You will receive a notification at the selected time '
                        'every day to remind you to check your plant\'s health.',
                        style: TextStyle(
                          color: Colors.grey,
                          fontSize: 14,
                        ),
                      ),
                    ),
                  ],
                ],
              ),
            ),
    );
  }
}
