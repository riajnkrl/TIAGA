import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/material.dart';

class NotificationSettings {
  static const String _timeKey = 'health_check_time';
  static const String _enabledKey = 'health_check_enabled';

  static Future<void> saveHealthCheckTime(TimeOfDay time) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_timeKey, '${time.hour}:${time.minute}');
    await prefs.setBool(_enabledKey, true);
  }

  static Future<TimeOfDay?> getHealthCheckTime() async {
    final prefs = await SharedPreferences.getInstance();
    final timeString = prefs.getString(_timeKey);
    if (timeString == null) return null;

    final parts = timeString.split(':');
    if (parts.length != 2) return null;

    return TimeOfDay(
      hour: int.parse(parts[0]),
      minute: int.parse(parts[1]),
    );
  }

  static Future<bool> isHealthCheckEnabled() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_enabledKey) ?? false;
  }

  static Future<void> setHealthCheckEnabled(bool enabled) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_enabledKey, enabled);
  }

  static Future<void> clearSettings() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_timeKey);
    await prefs.remove(_enabledKey);
  }
}
